%tenseur LDA
classdef tlda < handle
    
    properties
    %------------ INFO: method, file, data:type,dim,...
    info=struct('Method','LDA','DataLabels',[],'TargetLabels',[],'DimData',[],'FileName',[]);
    %------------ train and test data
    in= struct('DataTrain',[],'LabelTrain',[],'DataTest',[],'LabelTest',[],'DimSample',[],'Id',[]);  
    %------------- outputs of the classifier
    out=struct('Perf',[],'Dim',[]);  
    %------------- unknowns of the model
    model=struct('Sw',[],'Sb',[],'alpha',[],'U',[],'V',[],'Mu',[],'Index',[],'W',[],'Weight',[],'FR',[]); %U LDA, V PCA
    %------------- hyper parameters of the model
    par=struct('DimLDA',[],'DimPCA',[],'IterMax',10,'Reg',1e-3,'Ktype','r','Kpar',1);
    %-------------  options of the methods
    opt=struct('LimitNbData',1500,'ModeScale','No','ModeLearn','FromAll','ModeClass','multi class','TypeProd','n','Perf','Acc'); % typeProduct='c/'t'/''n')
    %'Perf': {'Acc','MatchScore'}
    %-------------  time
    cpu=struct('train',[]);
    end
  
    
methods    
   
    
function obj = tlda(varargin) 
PcTrain=[];
TargetLabels=[];
nVarargs = length(varargin);
for k = 1:2:nVarargs
    if strcmp(varargin{k},'Filename'),filename=varargin{k+1};end
    if strcmp(varargin{k},'ModeScale'),obj.opt.ModeScale=varargin{k+1};end
    if strcmp(varargin{k},'TargetLabels'),TargetLabels=varargin{k+1}; end 
    if strcmp(varargin{k},'Method'),obj.info.Method=varargin{k+1}; end 
    if strcmp(varargin{k},'TypeProduct'),obj.opt.TypeProd=varargin{k+1};end
    if strcmp(varargin{k},'PcTrain'),PcTrain=varargin{k+1};end
    if strcmp(varargin{k},'KType'),obj.par.Ktype=varargin{k+1};end
    if strcmp(varargin{k},'Kpar'),obj.par.Kpar=varargin{k+1};end
    if strcmp(varargin{k},'Perf'),obj.opt.Perf=varargin{k+1};end
    if strcmp(varargin{k},'ModeLearn'),obj.opt.ModeLearn=varargin{k+1};end
end

obj.info=InfoInit(obj,filename,TargetLabels);
clc;
ShowInfo(obj);
end

%%%%%% cross validation 
function [obj]=cv(obj,varargin)
K=5;
NbyClass=[];
Show=[];
nVarargs = length(varargin);
for k = 1:2:nVarargs    
  if strcmp(varargin{k},'Reg'),obj.par.Reg=varargin{k+1}; end 
  if strcmp(varargin{k},'K'),K=varargin{k+1}; end 
  if strcmp(varargin{k},'NbyClass'),NbyClass=varargin{k+1};end
 if strcmp(varargin{k},'Show'),Show=varargin{k+1};end
         % read N tensors by class
end
%%%%%% Preprocessing

m=matfile(obj.info.FileName);
label=m.label;%extract label
label=label(:);
vars = whos('-file',obj.info.FileName);
if ismember('Id', {vars.name}),Id=m.Id;label=label(1:Id(1));end

class=unique(label);
if isempty(NbyClass),figure(1),clf;hist(double(label),double(class));
    NbyClass=input('>> cross validation: How many tensors by class?','s');
    NbyClass=str2num(NbyClass);
end
close all
obj.in=ReadDataFromMat(obj,'NbyClass',NbyClass);  % read N tensors by class
[train,test]=DataPartition(obj.in.LabelTrain,'ByClass',K); % Label partition: K times

%cross validation step
handl=['ModelCV_',obj.opt.Perf];
obj.par=feval(handl,obj,train,test,Show);

end
%-------------------------------------------------------------------------%
function [obj]=learn(obj,varargin)
%-------------------------------------------------------------------------%
PcTrain=0.8;
Method=[];
Rep=[];

nVarargs = length(varargin);
for k = 1:2:nVarargs    
%     if strcmp(varargin{k},'TypeProduct'),obj.opt.TypeProd=varargin{k+1};end
  if strcmp(varargin{k},'ModeLearn'),obj.opt.ModeLearn=varargin{k+1};end
  if strcmp(varargin{k},'Ntensor'),Ntensor=varargin{k+1};end
  if strcmp(varargin{k},'PcTrain'),PcTrain=varargin{k+1};end
  if strcmp(varargin{k},'DimPCA'),obj.par.DimPCA=varargin{k+1}; end 
  if strcmp(varargin{k},'DimLDA'),obj.par.DimLDA=varargin{k+1}; end 
  if strcmp(varargin{k},'Reg'),obj.par.Reg=varargin{k+1}; end 
  if strcmp(varargin{k},'KType'),obj.par.Ktype=varargin{k+1};end
  if strcmp(varargin{k},'Kpar'),obj.par.Kpar=varargin{k+1};end
  if strcmp(varargin{k},'Rep'),Rep=varargin{k+1};end
end

switch obj.opt.ModeLearn
    
    case {'FromAll'}
        obj=ModelSolve_FromAll(obj,Ntensor,PcTrain,Rep);
     case {'FromId'}
        obj=ModelSolve_FromId(obj);
end

end

function [obj]=perf(obj,varargin)

show=[];
nVarargs = length(varargin);
for k = 1:2:nVarargs    
  if strcmp(varargin{k},'Show'),show=varargin{k+1};end    
end

switch obj.opt.Perf

    case 'Acc'
        disp(['>> Accuracy: ',num2str(mean(obj.out.Perf(end,:)))]);
        if ~isempty(show)
            figure(show)
            clf;
            x=obj.out.Dim;
            y=mean(obj.out.Perf,2);
            plot(x,y);
            grid on
        end

    case 'MatchScore'
        [dim,NProbe,r]=size(obj.out.Perf);
       
        A=cell(1,NProbe);
        for k=1:NProbe,A{k}=['T',num2str(k)];end
        B={'Rank 1';'Rank 5'};
        T=array2table(zeros(2,NProbe),'RowNames',B,'VariableNames',A);
        for i=1:r
            x=obj.out.Perf(:,:,i);
            for j=1:NProbe
            T{i,j}=x(dim,j);
            end
        end
       
        if ~isempty(show)
            c=linspace(0,1,NProbe)';
            color=[c,c,c];
            x=obj.out.Dim;
            figure(show)
            clf;
            subplot(1,2,1)
            y= obj.out.Perf(:,:,1);
            for k=1:NProbe
                h{k}=plot(y(:,k),'Color',color(k,:));
                hold on
            end
            %legend(h,A)
            xlabel('Dimension');
            ylabel('Rank 1')
             subplot(1,2,2)
            y= obj.out.Perf(:,:,2);
            for k=1:NProbe
                
                h1{k}=plot(y(:,k),'Color',color(k,:));
                hold on
            end
            xlabel('Dimension');
            ylabel('Rank 5')
            % legend(h,A)
        end
end
end

function [obj]=class(obj,varargin)
Show=[];
nVarargs = length(varargin);
for k = 1:2:nVarargs    
   if strcmp(varargin{k},'DimLDa'),obj.par.DimLDA=varargin{k+1};end
   if strcmp(varargin{k},'Show'),Show=varargin{k+1};end
end   
 
if strfind(obj.info.Method,'LDA')==1;F=obj.info.Method;else,F=[obj.info.Method,'_',obj.opt.TypeProd];end

Xp=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain);%projection
Yp=feval(F,obj,obj.in.DataTest,obj.in.LabelTest);

disp(['>> Accuracy: ',num2str(obj.out.Perf(end))]);

if ~isempty(Show)
R=[];
    for k=1:obj.par.DimLDA
        x=Xp(:,1:k);y=Yp(:,1:k);
        dyx=DistXY(y,x);
        [~,Idxy]=min(dyx, [], 2);
        lpredict=ltrain(Idxy); %predicted labels from ltrain
        R=[R;sum(lpredict==ltest)/length(ltest)]; %accuracy
    end
    figure(Show),clf;
    plot(R,'k');
    grid on,xlabel('Dimension');ylabel('Acc');
end
end


% function [obj]=classify(obj,varargin)
% Mode='Test';
% DimLDA=1; % all projectors
% nVarargs = length(varargin);
% for k = 1:2:nVarargs    
%    if strcmp(varargin{k},'DimLDA'),DimLDA=varargin{k+1};end
%    if strcmp(varargin{k},'Mode'),Mode=varargin{k+1};end
% end   
%  
% tab='> Projection and Classify....';
% disp(' ')
% disp(tab);
% 
% if sum(strcmp(obj.info.Method,{'Null_TLDA','Null_TKDA'}))
%     Xp=obj.model.C;
%     flag=0;
% else
%     Xp=TensorProjection(obj,obj.in.DataTrain);
%     flag=1;
% end
% if strcmp(Mode,'Train')
%     Yp=TensorProjection(obj,obj.in.DataTrain);
%     LY=obj.in.LabelTrain;
% else
%     Yp=TensorProjection(obj,obj.in.DataTest);
%     LY=obj.in.LabelTest;
% end
% 
% [obj.out.Score,obj.out.Label]=NearestNeighbor(Yp,Xp,obj.in.LabelTrain,DimLDA,flag);
% 
% obj.out.Perf=Accuracy(obj.out.Label,LY);
% 
%      
% end
% 
% function [obj]=class(obj,varargin)
% Mode='Test';
% Show=[];
% DimLDA=1; % all projectors
% nVarargs = length(varargin);
% for k = 1:2:nVarargs    
%    if strcmp(varargin{k},'DimLDA'),DimLDA=varargin{k+1};end
%    if strcmp(varargin{k},'Mode'),Mode=varargin{k+1};end
%    if strcmp(varargin{k},'Show'),Show=varargin{k+1};end
% end   
%  
% tab='> Projection and Classify....';
% disp(' ')
% disp(tab);
% 
% LT=obj.info.TargetLabels;
% if sum(strcmp(obj.info.Method,{'Null_TLDA','Null_TKDA'}))
%     
%     Xp=obj.model.C; Xp=permute(Xp,[2 1 3]);DimData=size(Xp);
%     X=reshape(Xp,[DimData(1),prod(DimData(2:3))]);LX=LT;
%     
%     Y=TensorProjection1(obj,obj.in.DataTest);LY=obj.in.LabelTest;
%     
%     [~,Acc]=NNAgg(X,LX,Y,LY,LT,1,1);
% 
%     if ~isempty(Show)
%         figure(Show),clf;
%         h1=plot(1:length(Acc),Acc*100,'b');
%         xlabel('number of learners'); ylabel('Acc(%)');legend(h1,'Acc.');
%         grid on
%     end
%     Accmax=max(Acc(:));
%     id=find(Acc==Accmax);
%     obj.out.perf=Acc(id);
% else
% 
%     %projection of training data
%     X=TensorProjection1(obj,obj.in.DataTrain);LX=obj.in.LabelTrain;
%     %projection of test data
%     Y=TensorProjection1(obj,obj.in.DataTest);LY=obj.in.LabelTest;
% 
%     [AccAgg,Acc]=NNAgg(X,LX,Y,LY,LT,DimLDA,1);
% 
%     if ~isempty(Show)
%         OutShowAcc(obj.par.Reg,Acc,AccAgg,Show)
%     end
%     Accmax=max(Acc(:));
%  [p,r]=find(Acc==Accmax);
%  [pmin,imin]=min(p);
%  obj.out.Perf=Accmax;
%  obj.out.Proj=pmin;
%  obj.out.Reg=obj.par.Reg(r(imin));
% 
% end
%  
% end

    
%-------------------------------------------------------------------------%  
function obj=result(obj,varargin)
%-------------------------------------------------------------------------%
nVarargs = length(varargin);
for k = 1:2:nVarargs    
    if strcmp(varargin{k},'type'),type=varargin{k+1};end
    if strcmp(varargin{k},'fig'),fig=varargin{k+1};end
end    

if strcmp(type,'learn score'),
ind=find(obj.in.lx==obj.in.target);
K=dd_kernel(obj.in.x(ind-1,:),obj.in.x,obj.par.ktype,obj.par.kpar);

    T=ComputeScore(obj,obj.model,K);
    figure(fig)
    clf;
    plot(T.dm);
    grid on
    xlabel('data');
    ylabel('learning score');
end
if strcmp(type,'test score'),
    [z,lz]=Read_TestData(obj,100);
    z=Standardization(obj,z);
    Kz=dd_kernel(z,obj.in.x,obj.par.ktype,obj.par.kpar);
    T=ComputeScore(obj,obj.model,Kz);
    obj.out.score=[T.dm(:),double(lz(:))];
    Out_ShowTestScore(obj,[],fig); 
end
if strcmp(type,'all'),Out_ShowAll(obj,fig); end
if strcmp(type,'ROC'),Out_ShowRoc(obj,fig); end
%if strcmp(type,'summary'),Out_Summary('ISVDD',obj); end
 
end
end
end

function [S]=BuildSmode(H,mode,U)
% H tab of cells
S=0;

for k=1:size(H,2)
    
    %projection of H 
    if nargin==3
        Nmode=size(U,2);
        dim=1:Nmode;dim(mode)=[];
        Hp=ttm(tensor(H{k}),U(dim)',dim);
        Hp_mode=tenmat(Hp,mode);
    else
         Hp_mode=tenmat(H{k},mode);
    end
    S=S+Hp_mode.data*Hp_mode.data';
end
  


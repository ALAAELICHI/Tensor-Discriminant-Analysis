function [S]=BuildModeScatter(H,U,mode,NbMode)
% H tab of cells
S=0;
OtherModes=1:NbMode;
OtherModes(mode)=[];
for k=1:size(H,2)
    
    %projection of H 
    Hp=ttm(tensor(H{k}),U(OtherModes)',OtherModes);
    Hp_mode=tenmat(Hp,mode);
    S=S+Hp_mode.data*Hp_mode.data';
end
  


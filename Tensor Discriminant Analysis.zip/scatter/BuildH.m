function [Hb,Hw]=BuildH(obj,X,LX)

% X: tensor centered with ist global mean
% Label: classes of tensors
% TargetLabels
%DimSample: index of the tensor where the samples are present
%
%Extract

DimSample=obj.in.DimSample;
DimData=size(X);
dim=ones(1,length(DimData)); 
C=unique(LX);

u=1;
for k=1:length(C)
    id=find(LX==C(k));
    nk=length(id);
    Xk=ExtractTensor(X,id,DimSample);
    Muk=mean(Xk,DimSample);
    dim(DimSample)=nk;
    Hb{k}=Muk*sqrt(nk);
    Hw{k}=Xk-repmat(Muk,dim);

end
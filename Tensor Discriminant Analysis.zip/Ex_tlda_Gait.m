clear all
close all

%addpath('..\utils');
addpath('method');
addpath('scatter');
addpath('utils');
filename='G:\Data_Base\tensor data base\Gait database\GaitImage4D_4527.mat';%NbyClass=15;

tlda=tlda('Filename',filename,'ModeLearn','FromId','Method','TLDA','TypeProduct','t','Perf','MatchScore');

tlda.cv('Reg',[10.^-(0:7)],'K',1,'Show',1,'NbyClass',[]);
tlda.learn();
tlda.perf('Show',2);
%dispstat('Finished.','keepprev');


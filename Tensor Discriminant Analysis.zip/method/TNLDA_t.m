function [W,C]=TNLDA_t(obj,X,Label)
%variables
TargetLabels=obj.info.TargetLabels;
U=PCA(fft(X,[],3));
Xp=tprod(tran(U),X);
Xw=BuildXw(Xp,Label,TargetLabels);
V=NullSw(fft(Xw,[],3));
W=tprod(U,V);
C=BuildNullCenter(W,X,Label,TargetLabels);


function [V,WV]=PCA(X)

DimData=size(X);
DimSample=2;

dim=ones(1,3); 
dim(DimSample)=size(X,DimSample);

Mu=mean(X,DimSample);
X=X-repmat(Mu,dim);
%X=bdiag(X);

n1=DimData(1);n2=DimData(2);n3=DimData(3);

for k=1:n3
    S=X(:,:,k)'*X(:,:,k);
    [U, D, ~] = svd(S);
    d=diag(D);
    I=find(d>1e-5);
    d1=d(I).^(-1/2);
        %V(:,:,k)=X(a,b)*U(:,I)*diag(d);
%     V{k}=X(:,:,k)*U(:,I)*diag(d1);
%     WV{k}=d(I);
    V(:,:,k)=X(:,:,k)*U(:,I)*diag(d1);
    WV(:,:,k)=d(I);
end

%[V,WV]=SortEigenValues(V,WV);
V=ifft(V,[],3);
WV=ifft(WV,[],3);


function [V]=NullSw(Xw)

DimData=size(Xw);
%Xw=bdiag(Xw);

n1=DimData(1);n2=DimData(2);n3=DimData(3);
for k=1:n3
%     a=(k-1)*n1+1:k*n1;
%     b=(k-1)*n2+1:k*n2;
%    V(:,:,k)=null(Xw(a,b)');
     V(:,:,k)=null(Xw(:,:,k)');   
end
V=ifft(V,[],3);


function [C]=BuildNullCenter(W,X,Label,TargetLabels)
DimSample=2;

for k=1:length(TargetLabels)
    
    id=find(Label==TargetLabels(k));
    nk=length(id);
    Xk=X(:,id,:);
    Muk=mean(Xk,DimSample);
    C(:,k,:)=tprod(tran(W),Muk);
end

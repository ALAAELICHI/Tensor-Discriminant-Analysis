function [obj]=ModelSolve_FromAll(obj,Ntensor,PcTrain,Rep)

if strfind(obj.info.Method,'LDA')==1;F=obj.info.Method;else,F=[obj.info.Method,'_',obj.opt.TypeProd];end

for k=1:Rep
      obj.in=ReadDataFromMat(obj,'NbyRand',Ntensor,'PcTrain',PcTrain);
  
      obj.model=struct('Sw',[],'Sb',[],'alpha',[],'U',[],'V',[],'Mu',[]);% Reset model
      if Rep==1
        dispstat(sprintf('>> Learning ...'),'keepthis','timestamp');
      else
        dispstat(sprintf('>> Learning with repetition --> progress %d%%',round(100*k/Rep)),'timestamp');
      end
    tic,
    obj.model=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain); % %init model
    obj.model=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain); % %model solve
    obj.cpu.train=[obj.cpu.train;toc];

    x=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain);%projection
    y=feval(F,obj,obj.in.DataTest,obj.in.LabelTest); %projection
    dim=SampleDim(size(x,2)); 
    
    if strcmp(obj.opt.Perf,'Acc')
        Acc=NNAcc(dim,x,obj.in.LabelTrain,y,obj.in.LabelTest);
        obj.out.Perf(:,k)=Acc(:);
        obj.out.Dim=dim;
    end
     if strcmp(obj.opt.Perf,'MatchScore')
         [R1,R5]=MatchScore(dim,obj.in.LabelTrain,y,obj.in.LabelTest);
          obj.out.Perf(:,k,1)=R1(:);
          obj.out.Perf(:,k,2)=R5(:);
           obj.out.Dim=dim;
     end
    
end


function [tab]=SampleDim(NProj)

i2=NProj;

%projection sampling
if i2<100,   tab=linspace(1,i2,i2);end
if (i2>=100)&(i2<1000),tab=round(linspace(1,i2,100));end
if (i2>=1000),tab=round(linspace(1,1000,250));end


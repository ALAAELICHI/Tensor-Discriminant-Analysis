
function [out]=LDA(obj,X,LX)

out=obj.model;
par=obj.par;
DimData=size(X);

%compute sample mean and centering
if isempty(out.Mu),out.Mu=mean(X,2);end
X=X-repmat(out.Mu,[1 DimData(2)]);

% PCA projection
if (par.DimPCA>0)
 if isempty(out.V),out.V=PCA(obj,X);end
 X=out.V'*X;
end
%init model
if isempty(out.alpha)
  %Scatter matrix
  [Sb,Sw]=BuildScatter(obj,X,LX);
  [~,out.alpha]=eigs(Sw,1,'la',struct('disp',0));
  
else
    %solve model
    if isempty(out.U) %solve model

        %dimension of LDA
        C=length(obj.info.TargetLabels);
        DimLDA=C-1;
        %build scatter matrices
       [Sb,Sw]=BuildScatter(obj,X,LX);
        %regularization of LDA
        Sw=Sw+par.Reg*out.alpha*eye(size(Sw)); %regularization

        [U,D,~]=svd(inv(Sw)*Sb);
        d=diag(D);

        %build output
        out.U=U(:,1:DimLDA);
      
       % d=d(1:DimLDA);
        %WU=sqrt(d);
%disp(['>> LDA: ', num2str(DimData(1)),' --> ',num2str(DimLDA)]);

        else   %projection

            Xp=out.U'*X; 
            out=Xp'; 
        end
end




function [Sb,Sw]=BuildScatter(obj,X,LX)


dim=ones(1,2); 

Sb=0;Sw=0;
for k=1:length(TargetLabels)
    id=find(LX==TargetLabels(k));
    nk=length(id);
    Xk=X(:,id);%ExtractTensor(X,id,DimSample);
    Muk=mean(Xk,2);
    dim(2)=nk;
    Sb=Sb+nk*Muk*Muk';
    Sw=Sw+(Xk-repmat(Muk,dim))*(Xk-repmat(Muk,dim))';
end
function [U,WU,DimPCA]=PCA(obj,X)
alpha=obj.par.DimPCA;

S=X*X';

[U, D, ~] = svd(S);
d=diag(D);
I=find(d>1e-10);
DimOut=length(I);
if isempty(alpha),
    DimPCA=length(I);
else
    if alpha<1,
        cs=cumsum(d(I));
        cs=cs/cs(end);
        DimPCA=length(find(cs<alpha));
    end
end

U=U(:,1:DimPCA);
WU=d(1:DimPCA);
disp(['>> PCA:',num2str(alpha),'% variance: ', num2str(DimOut),' --> ',num2str(DimPCA)]);



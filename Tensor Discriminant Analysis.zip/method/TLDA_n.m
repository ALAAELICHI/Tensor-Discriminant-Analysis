function [out]=TLDA_n(obj,X,LX)


%extract parameters
out=obj.model;
par=obj.par;

DimData=size(X);
N=DimData(end);
Nmode=length(DimData)-1;

dim=ones(1,length(DimData));
dim(end)=N;


%compute sample mean and centering
if isempty(out.Mu),out.Mu=mean(X,length(DimData));end
X=X-repmat(out.Mu,dim);

if isempty(out.alpha)
    out.alpha=InitAlpha(obj,X,LX);
else
    
    if isempty(out.U)
       %init scatter matrices
        [Hb,Hw]=BuildH(obj,X,LX);
       %Init Projector
        U_old=InitU(DimData,Nmode);
    
        i=1;err=1;
        while (i<par.IterMax)&(err>1e-6)
         
            for mode=1:Nmode
                %projection of scatter matrices on U_old for k=1:NbMode (k\\mode)
                Sb=BuildSmode(Hb,mode,U_old);
                Sw=BuildSmode(Hw,mode,U_old);
                Sw=Sw+par.Reg*out.alpha(mode)*eye(size(Sw)); %regularization of Sw out.alpha(mode)

                %[~,rho]=eigs(inv(Sw)*Sb,1,'la',struct('disp',0));   
                 rho=MDACriterion(Sb,Sw,U_old{mode}');
                [V,D,~]=svd(Sb-rho*Sw);
                d=diag(D);
                %[V,D]=eigs(inv(Sw)*Sb,1,'la',struct('disp',0)); 
                %I=find(d>1e-7);
                %Vn=NormV(V(:,I));
                %Vn=V(:,I);
                Vn=NormV(V);
                U{mode}=Vn';
            end
            if i>1,err=StopCrit(U_old,U);end
    
            U_old=U;
            i=i+1;
        end
        out.U=U_old;
    else  %projection 
    
        N=ndims(X);dim=1:N;dim(end)=[];
        Xp=ttm(tensor(X),out.U',dim);Xp=Xp.data;
        Xp=permute(Xp,[N,1:N-1]);
        DimData=size(Xp);
        out=reshape(Xp,[DimData(1),prod(DimData(2:N))]);

    end

end
       
   
function [U]=InitU(DimData,NbMode)
    for mode=1:NbMode
        u=ones(DimData(mode),1);un=norm(u);
        U{mode}=ones(DimData(mode),DimData(mode))/un; %dimOut/features(d)
    end

function [alpha]=InitAlpha(obj,X,LX)

DimData=size(X);
Nmode=length(DimData)-1;          
option=struct('disp',0);
[Hb,Hw]=BuildH(obj,X,LX);
for mode=1:Nmode
     Sw=BuildSmode(Hw,mode);
    [~,alpha(mode)]=eigs(Sw,1,'la',option);    
end

function [Vn]=NormV(V)
    
    for k=1:size(V,2)
        Vn(:,k)=V(:,k)/norm(V(:,k));
    end

function [DimOut]=TheshDimOut(d,alpha)
if isempty(alpha),
    DimOut=length(d);
else
    if alpha<1,
        cs=cumsum(d);
        cs=cs/cs(end);
        DimOut=sum(cs<alpha);
    end
end


% %%%%%%%%%%%%% added
%         N=ndims(X);dim=1:N;dim(obj.in.DimSample)=[];
%         Xp=ttm(tensor(X),out.U',dim);Xp=Xp.data;
%         Xp=permute(Xp,[N,1:N-1]);
%         DimData=size(Xp);
%         Xp=reshape(Xp,[DimData(1),prod(DimData(2:N))]);
%         [out.Index,out.Weight,out.W,out.FR]=SortFisherRatio(Xp,LX);

% %%%%%%%%%%%%%%%%%%%%%added
%         Xp=Xp(:,out.Index);
%          out=Xp*out.W;


function [U,WU]=TLDA_c(obj,X,LX)

%variables
TargetLabels=obj.info.TargetLabels;
DimSample=obj.in.DimSample;
IterMax=obj.par.IterMax;

DimData=size(X);
dim=ones(1,length(DimData)); 
NbMode=length(DimData)-1;

%Init Projector
for mode=1:NbMode
    U_old{mode}=ones(obj.par.DimLDA(mode),DimData(mode));
end

X=fft(X,[],2);
%Init of the cells Hb and Hw for building scatter matrices: Sb=Sb+Hb{k}*Hb{k}', Sw=Sw+Hw{k}*Hw{k}'
for k=1:length(TargetLabels)
    id=find(LX==TargetLabels(k));
    nk=length(id);
    Xk=ExtractTensor(X,id,DimSample);
    Muk=mean(Xk,DimSample);
    dim(DimSample)=nk;
    
   Hb{k}=Muk*sqrt(nk);
   Hw{k}=Xk-repmat(Muk,dim);
end


tol=1e-4;
err(1)=-1; 
for i=1:IterMax
  
    i
    for mode=1:NbMode
        
        %build scatter matrices
        Sb=BuildModeScatter(Hb,U_old,mode,NbMode);
        Sw=BuildModeScatter(Hw,U_old,mode,NbMode);
 
        %[V,D]=svd(pinv(Sw)*Sb);
        
         Sw=Sw+0.0001*eye(DimData(mode));
         rho(i)=MDACriterion(Sb,Sw,U_old{mode}');
         [V,D,~]=svd(Sb-rho(i)*Sw);
         d=diag(D);
        
        U{mode}=V(:,1:obj.par.DimLDA(mode))';
        WU{mode}=d(1:obj.par.DimLDA(mode));
        
    end
    
    if i>1,
        err(i)=StopCrit(U_old,U); 
        if err(i)<tol,
             obj.model.MDA= [obj.model.MDA;[rho(:),err(:)]];
            break;
        end
    end
    
    U_old=U;

end

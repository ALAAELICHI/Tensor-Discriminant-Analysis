function [U,E]=TPCA_t(obj,X)
%variables
DimSample=obj.in.DimSample; %N� of dim :NbSample 
DimPCA=obj.par.DimPCA; %dim of projection
DimData=size(X); %dimension of the tensor
 
dim=ones(1,length(DimData)); 
dim(DimSample)=DimData(2);

X=fft(X,[],3);

Mu=mean(X,DimSample);
X=X-repmat(Mu,dim);


if length(DimData)==3
    n3=DimData(3);
    for k=1:n3
          [UU{k},EE{k},N(k)]=PCA(obj,X(:,:,k));
    end
else
    n3=1;
       [UU{1},EE{1},N(1)]=PCA(obj,X(:,:));
end
 N=min(N);

 for k=1:n3
     u=UU{k};
     e=EE{k};
     U(:,:,k)=u(:,1:N);
     E(:,:,k)=diag(e(1:N));
 end
 
%[U1,E,U2]=SVD_BdiagMat(X*X',DimData(1),DimData(1),DimData(3),DimPCA);
%[U,E]=SortEigenValues(U,E);

U=ifft(U,[],3);
E=ifft(E,[],3);



function [Us]=TULDA_n(obj,X,LX)
% X is the zero mean  training data

%extract info method
TargetLabels=obj.info.TargetLabels;
IterMax=10;%obj.par.IterMax;
Reg=obj.par.Reg;

DimData=size(X);
Nmode=length(DimData)-1;
Nreg=length(Reg);
Ndir=obj.par.DimLDA;


%init alpha
alpha=InitAlpha(obj,X,LX);
%alpha1=estMaxSWEV(X,uint8(LX))



for t=1:Nreg  %several regularization 
    t
     Yp=[];
     U=InitU(Nmode,Ndir,DimData);  %init projector

    for i_dir=1:Ndir % number of projections
        
        for iter=1:IterMax %iteration for convergence (
            %[iter,IterMax,i_dir]
            
            for n=1:Nmode  %iteration for  modes
            
                dim=1:Nmode; dim(n)=[];
                Y=ttv(tensor(X),U(dim,i_dir),dim);Y=Y.data;
                
                [Sb,Sw]=BuildScatter(Y,LX,TargetLabels);
                Sw=Sw+Reg(t)*alpha(n)*eye(size(Sw,1));
                Rb=WeightSb(Y,Sw,Yp);
                [Un,Wun]=eigs(Rb*Sb,Sw,1,'la',struct('disp',0));
                Un=Un/norm(Un);
                U{n,i_dir}=Un;
            end
       
         end
    dim=1:Nmode;
    yp=ttv(tensor(X),U(:,i_dir),dim);yp=yp.data;
    Yp=[Yp,yp];
    end
    Us{t}=U;
    clear U
end
        


function [U0]=InitU(Nmode,Ndir,DimData)
for d=1:Ndir
    for n=1:Nmode
       Un=ones(DimData(n),1); %uniform initialization
       U0{n,d}=Un/norm(Un);
       
    end
end


function [Sb,Sw]=BuildScatter(X,LX,LT)

dim=size(X,1);
Sw=eye(dim);
Sb=eye(dim);

for k=1:length(LT)
    id=find(LX==LT(k));
    Xk=X(:,id);
    Muk=mean(Xk,2);
    nk=length(id);
    Xk=Xk-repmat(Muk,[1,nk]);
    Sw=Sw+Xk*Xk';
    Sb=nk*Muk*Muk';
end

function Rb=WeightSb(Ypn,SW,Gps)
        kappa=1e-3;
        dim=size(SW,1);
        
        if isempty(Gps)
            Rb=1;
        else
             idir=size(Gps,2);
             invSW=inv(SW);
             invGYYG=inv(Gps'*Ypn'*invSW*Ypn*Gps+kappa*eye(idir));
             Rb=(eye(dim)-Ypn*Gps*invGYYG*Gps'*Ypn'*invSW);%equation (13) in
        end
        
function [alpha]=InitAlpha(obj,X,LX)

DimData=size(X);
Nmode=length(DimData)-1;          
option=struct('disp',0);
[Hb,Hw]=BuildH(obj,X,LX);
for mode=1:Nmode
    
    Sw=BuildSmode(Hw,mode);
    [~,alpha(mode)]=eigs(Sw,1,'la',option);    
end
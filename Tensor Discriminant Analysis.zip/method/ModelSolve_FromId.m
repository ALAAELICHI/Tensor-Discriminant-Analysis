function [obj]=ModelSolve_FromId(obj,Ntensor,PcTrain,Rep)

if strfind(obj.info.Method,'LDA')==1;F=obj.info.Method;else,F=[obj.info.Method,'_',obj.opt.TypeProd];end
obj.in=ReadDataFromMat(obj);

%learning 
dispstat(sprintf('>> Learning ...'),'keepthis','timestamp');
obj.model=struct('Sw',[],'Sb',[],'alpha',[],'U',[],'V',[],'Mu',[]);% Reset model
 tic,
 obj.model=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain); % %init model
 obj.model=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain); % %model solve
 x=feval(F,obj,obj.in.DataTrain,obj.in.LabelTrain);%projection
 obj.cpu.train=[obj.cpu.train;toc];

 dim=SampleDim(size(x,2)); 
 DimSample=obj.in.DimSample;
 
 NId=size(obj.in.Id,1);
for k=1:NId
      
    dispstat(sprintf('>> Learning With the Id Table --> progress %d%%',round(100*k/NId)),'timestamp');
    
    itst=obj.in.Id(k,1):obj.in.Id(k,2); %define index from probes
    
    y=ExtractTensor(obj.in.DataTest,itst,DimSample);%extract corresponding tensors
    ly=obj.in.LabelTest(itst);
   
    y=feval(F,obj,y,ly); %projection
    
    
    if strcmp(obj.opt.Perf,'Acc')
        Acc=NNAcc(dim,x,obj.in.LabelTrain,y,ly);
        obj.out.Perf(:,k)=Acc(:);
        obj.out.Dim=dim;
    end
     if strcmp(obj.opt.Perf,'MatchScore')
         [R1,R5]=MatchScore(dim,x,obj.in.LabelTrain,y,ly);
          obj.out.Perf(:,k,1)=R1(:);
          obj.out.Perf(:,k,2)=R5(:);
           obj.out.Dim=dim;
     end
    
end


function [tab]=SampleDim(NProj)

i2=NProj;

%projection sampling
if i2<100,   tab=linspace(1,i2,i2);end
if (i2>=100)&(i2<1000),tab=round(linspace(1,i2,100));end
if (i2>=1000),tab=round(linspace(1,1000,250));end


function [W,C]=TNKDA_t(obj,X,Label)
%variables
TargetLabels=obj.info.TargetLabels;
Ktype=obj.par.Ktype;
Kpar=obj.par.Kpar;
N=size(X,2);
W=eye(N)-BuildMatL(Label(:),TargetLabels);

%build Kernel 
for k=1:size(X,3)%n3
    x=X(:,:,k)';
    K(:,:,k)=dd_kernel(x,x,Ktype,Kpar(k));
    Kw(:,:,k)=K(:,:,k)*W;
end
U=KPCA(fft(K,[],3));

% Kp=tprod(tran(U),K);
% V=NullKSw(fft(Kp,[],3),Label,TargetLabels);
Kp=tprod(tran(U),Kw);
V=NullKSw1(fft(Kp,[],3));
W=tprod(U,V);

C=BuildNullCenter(W,K,Label,TargetLabels);




function [V]=KPCA(K)

DimData=size(K);
n3=DimData(3);
N=DimData(2);
T=eye(N)-ones(N)/N;
for k=1:n3
    [U, D, ~] = svd(T*K(:,:,k)*T);
    d=diag(D);
    I=find(d>1e-10);
    d=d(I).^(-1/2);
    V(:,:,k)=T*U(:,I)*diag(d);
end
V=ifft(V,[],3);

function L=BuildMatL(lab,TL)

n=length(lab); % number of data
L = zeros(n,n);
for k=1:length(TL)
    I=(lab==TL(k));
    if ~isempty(I)
        L(I,I) = 1/sum(I);
    end
end


function [V]=NullKSw1(Kp)

DimData=size(Kp);
n3=DimData(3);
for k=1:n3
     V(:,:,k)=null(Kp(:,:,k)');   
end
V=ifft(V,[],3);

function [V]=NullKSw(Kp,Label,TargetLabels)

DimData=size(Kp);
%Xw=bdiag(Xw);
N=length(Label);
W=eye(N)-BuildMatL(Label(:),TargetLabels);

n3=DimData(3);
for k=1:n3
     V(:,:,k)=null((Kp(:,:,k)*W)');   
end
V=ifft(V,[],3);


function [C]=BuildNullCenter(W,K,Label,TL)

DimSample=2;

for c=1:length(TL)
    
    Ic=find(Label==TL(c));
    %nc=length(Ic);
    Kc=K(:,Ic,:);
    M_Kc(:,c,:)=mean(Kc,DimSample);  %|:|c
    
%     M_Kc=mean(Kc,DimSample);
%     C(:,c,:)=tprod(tran(W),M_Kc);
end

C=tprod(tran(W),M_Kc);
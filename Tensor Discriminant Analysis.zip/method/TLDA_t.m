function [out]=TLDA_t(obj,X,Label)

%extract parameters
out=obj.model;
par=obj.par;

n3=size(X,3);
n2=size(X,2);

%compute sample mean and centering
if isempty(out.Mu),out.Mu=mean(X,2);end
X=X-repmat(out.Mu,[1 n2 1]);

% PCA projection
if ~isempty(par.DimPCA)
    if isempty(out.V),out.V=TPCA_t(obj,X);end
    X=tprod(tran(out.V),X);
end

if isempty(out.alpha)
    %fft on X
    X=fft(X,[],3);

    %Build scatter for each mode in the fourier domain
    for mode=1:n3
        [out.Sb{mode},out.Sw{mode}]=BuildScatter(X(:,:,mode),Label);
        [~,out.alpha{mode}]=eigs(out.Sw{mode},1,'la',struct('disp',0));    
    end
else

    if isempty(out.U)
        %solve the optimization criterion in the foureir domain: for each
        n1=size(X,1);
        C=length(unique(Label));%number of classes
        for k=1:n3
            [U{k},D{k}]=TraceRatioOptim(out.Sb{k},out.Sw{k}+par.Reg*out.alpha{k}*eye(n1),C);
        end
        [U,D]=SortEigenValues(U,D,0);
        
        out.U=ifft(U,[],3);
        
    else  %projection 
        Xp=tprod(tran(out.U),X);
        Xp=permute(Xp,[2 1 3]);
        DimData=size(Xp);
        if length(DimData)==3
            out=reshape(Xp,[DimData(1),prod(DimData(2:3))]);
        else
            out=Xp;
        end
    end

end




function [Sb,Sw]=BuildScatter(X,Label)
Mu=mean(X,2);
Class=unique(Label);
%building scatter matrices: Sb=Sb+Hb{k}*Hb{k}', Sw=Sw+Hw{k}*Hw{k}'
Sb=0;Sw=0;
for k=1:length(Class)
    
    id=find(Label==Class(k));
    nk=length(id);
    Xk=X(:,id); %extract tensor by class 
    Muk=mean(Xk,2)-Mu; %class mean
    Xk=Xk-repmat(Muk,[1,nk]);%centering tensor by class
    %update Sb and Sw
    Sb=Sb+nk*Muk*Muk';
    Sw=Sw+Xk*Xk';
   
end

        
        

 function [U,D,MDA]=RatioTraceOptim(Sb,Sw,IterMax) %trace ratio optimization

DimIn=size(Sb,1);
U_old=ones(DimIn,DimIn);

tol=1e-5; err=1; i=1;
while (err > tol) && (i <IterMax) 
    
    %compute rho: value of the objectiive function for U_old
    rho=trace(U_old'*Sb*U_old)/trace(U_old'*Sw*U_old);
   [U,D]=svd(Sb - rho * Sw);
    d=diag(D);
    DimOut=sum(d>1e-10);
    U=U(:,1:DimOut);
    D=diag(d(1:DimOut));
    
    %build stop criterion
    A=U_old(:,1:DimOut)*U';
    err=norm(A-eye(DimIn,DimIn),'fro')/(DimIn*DimIn)
 
    U_old=U;
i=i+1;

end

 function [U,D]=TraceRatioOptim(Sb,Sw,C)

[U,D,~]=svd(inv(Sw)*Sb);
d=diag(D);
U=U(:,1:C-1);
D=d(1:C-1);
%disp(['>> LDA: ', num2str(size(Sb,1)),' --> ',num2str(DimLDA)]);


 
    %[ V, D1] = eigs( Sb - rho * Sw, DimOut,'largestreal', 'FailureTreatment','drop' );
%      [size(Sw,1),rank(Sb),rank(Sw)]
%      rho=0:5:100;
%      for t=1:length(rho)
%          f(t,1)=rank(Sb+rho(t)*Sw);
%          f(t,2)=rank(Sb)+rank(Sw);
%      end
%      figure(1)
%      clf;
%      plot(rho,f(:,1),'b');
%      hold on
%      plot(rho,f(:,2),'r');
%      pause
     %[rank(Sb-rho*Sw),rank(Sb)+rank(Sw)]
%     pause



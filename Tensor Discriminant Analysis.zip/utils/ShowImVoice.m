function ShowImVoice(A,label,digit,fig)

id=find(label==digit);
figure(fig)
clf;
subplot(1,2,1)
imshow(uint8(A(:,:,1,id(1))),[]);
subplot(1,2,2)
contourf(A(:,:,2,id(1)),15);
axis square
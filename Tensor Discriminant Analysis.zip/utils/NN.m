function [lpredict,score]=NN(x,ltrain,y)

    
     dyx=DistXY(y,x);
    [score,Idxy]=min(dyx, [], 2);
    lpredict=ltrain(Idxy); %predicted labels from ltrain
    %Acc=sum(lpredict==ltest)/length(ltest); %accuracy
function [W,EW]=SortEigenValues(U,E,tri)
% E is the eigenvalue vector
V=[];D=[];
n3=size(U,2);
for k=1:n3
    e=E{k};
    D=[D;e(:)];
    V=[V,U{k}];
   dimout=length(e);
end

if tri==1
    [D,ind]=sort(D,'descend');
    V=V(:,ind);
end
N=size(V,2);

if N~=(n3*dimout)
    disp('>> error of size in U!!');
    W=[];
    EW=[];
    exit();
else
    for k=1:n3
         a=(k-1)*dimout+1:k*dimout;
         W(:,:,k)=V(:,a);
         EW(:,:,k)=diag(D(a));
    end
end
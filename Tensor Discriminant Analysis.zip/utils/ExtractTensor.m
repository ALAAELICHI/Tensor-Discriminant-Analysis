function [xc]=ExtractTensor(X,id,N)


switch ndims(X)

case 2
     xc=X(:,id);

case 3
      if N==2,xc=X(:,id,:);else, xc=X(:,:,id);end

case 4
      xc=X(:,:,:,id);
        
case 5
      xc=X(:,:,:,:,id);
        
otherwise
     disp('> order not supported!!');
 end
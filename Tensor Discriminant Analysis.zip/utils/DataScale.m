function [X]=DataScale(X,ModeScale)


DimData=size(X);
DimSample=length(DimData);
NTensor=DimData(DimSample);
dim=ones(1,DimSample); 
dim(DimSample)=NTensor;

switch ModeScale
    
    case 'Min-Max'
        
          m=min(X,[],DimSample);
          M=max(X,[],DimSample);
          DimM=size(M);
         
          if length(DimM)>2
            m=reshape(m,[prod(DimM(1:2)),DimM(3:end)]); m=min(m,[],1);
            M=reshape(M,[prod(DimM(1:2)),DimM(3:end)]);M=max(M,[],1);
            m=ReshapeData(m,DimM(1:2));
            M=ReshapeData(M,DimM(1:2));
          else
              m=min(m(:))*ones(DimM);
              M=max(M(:))*ones(DimM);
              
          end
         
          X=(X-repmat(m,dim))./(repmat(M,dim)-repmat(m,dim));
    case 'Std'
          m=mean(X,DimSample);
          M=std(X,0,DimSample);
          DimM=size(M);
          m=reshape(m,[prod(DimM(1:2)),DimM(3:end)]); m=min(m,[],1);
          M=reshape(M,[prod(DimM(1:2)),DimM(3:end)]);M=max(M,[],1);
          m=ReshapeData(m,DimM(1:2));
          M=ReshapeData(M,DimM(1:2));
          X=X-repmat(m,dim);
          X=X./repmat(M,dim);
    
end

function [Y]=ReshapeData(X,dim)
DimData=size(X);
N=ndims(X);

switch N
    
    case 2

    for k=1:DimData(2)
        Y(:,:,k)=X(1,k)*ones(dim(1),dim(2));
    end
    
    case 3
        for i=1:DimData(3)
            for j=1:DimData(2)
                Y(:,:,j,i)=X(1,j,i)*ones(dim(1),dim(2));
            end
        end
        
     case 4
        for i=1:DimData(4)
            for j=1:DimData(3)
                for k=1:DimData(2)
                Y(:,:,k,j,i)=X(1,k,j,i)*ones(dim(1),dim(2));
                end
            end 
        end
    
end


    

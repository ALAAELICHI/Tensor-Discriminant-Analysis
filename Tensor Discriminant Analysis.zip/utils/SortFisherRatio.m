function [Index,Weight,U,FisherRatio]=SortFisherRatio(X,LX)

% X: data projected row: nsample, column: dim
%LX=Label

[N,dim]=size(X);
%%%%%%%%%%%%%%%Sort according to Fisher's discriminality%%%%%%%%%%%%%%%
class = unique(LX);
C = length(class);%Number of classes
ClassId=cell(C);
ClassNb=zeros(C,1);
for c=1:C
    ClassId{c}=find(LX==class(c));
    ClassNb(c)=length(ClassId{c});
end

%Compute Fisher ratio/projections
Mu=mean(X)';
TSW=0;
TSB=0;

for c=1:C
    Xc=X(ClassId{c},:)';
    Muc=mean(Xc,2);
    FtrDiff=Xc-repmat(Muc,1,ClassNb(c));
    TSW=TSW+sum(FtrDiff.*FtrDiff,2);
    meanDiff=Muc-Mu;
    TSB=TSB+ClassNb(c)*meanDiff.*meanDiff;
end
FisherRatio=TSB./TSW;
[FisherRatio,Index]=sort(FisherRatio,'descend');


%compute Weight from LDA
X=X(:,Index);
Mu=mean(X)';

SW=0;
SB=0;

for c=1:C
    Xc=X(ClassId{c},:)';
    Muc=mean(Xc,2);
    FtrDiff=Xc-repmat(Muc,1,ClassNb(c));
    SW=SW+FtrDiff*FtrDiff';
    meanDiff=Muc-Mu;
    SB=SB+ClassNb(c)*meanDiff*meanDiff';
end

if rank(SW)<dim,SW=SW+1e-3*eye(dim);end
option=struct('disp',0);
[U,D,~]=eigs(inv(SW)*SB,C-1,'lm',option);

Weight=sqrt(diag(D));
%Index=Index(1:C-1);
function ShowInfo(obj)
id=find(obj.info.FileName=='\');
id=id(end)+1;
tab=['> Data: ',obj.info.FileName(id:end),' - nb Classes: ',num2str(length(obj.info.TargetLabels))];
tab=[tab,['\n \t \t > Dim: ', num2str(obj.info.DimData)]];
tab=[tab,['\n \t \t > Method: ',obj.info.Method,' - Type Product: ',lower(obj.opt.TypeProd),'-product']];
tab=[tab,['\n \t \t > Mode Learning: ',obj.opt.ModeLearn,' - Perf. measure: ',obj.opt.Perf,'\n']];

dispstat('','init'); % One time only initialization
dispstat(sprintf(tab),'keepthis','timestamp');



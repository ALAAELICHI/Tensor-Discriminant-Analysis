function [Acc,AccAgg]=NNAgg(dim,Xp,LX,Yp,LY)

for i=1:length(dim),[Acc(i,:),AccAgg(i,:)]=ANNReg(dim(i),Xp,LX,Yp,LY);end

 
function [Acc,AccAgg]=ANNReg(i,Xp,LX,Yp,LY)

Nreg=size(Xp,3);
Class=unique(LX);
C=length(Class);

for k=1:C
    Id_Class{k}=find(LX==Class(k));
end

%compute Accuracy
    for j=1:Nreg
          
            x=Xp(:,1:i,j);
            y=Yp(:,1:i,j);
            
            dyx=DistXY(y,x);
            [~,Idxy]=min(dyx, [], 2);

            LP=LX(Idxy); %predicted labels from LX
            Acc(1,j)=sum(LP==LY)/length(LY); %accuracy for one learner
            
            for c=1:C
             dyx_c=dyx(:,Id_Class{c});
             Dyx(:,c,j)=min(dyx_c,[],2);
            end
            
            %normlize between 0 and 1
            m=min(Dyx(:,:,j),[],2);
            M=max(Dyx(:,:,j),[],2);
            Dyx(:,:,j)=(Dyx(:,:,j)-repmat(m,1,C))./(repmat(M-m,1,C));
            dyx=[];
     end
       
    %compute aggregate Accuracy 
    for j=1:Nreg
          Dyx_agg=sum(Dyx(:,:,1:j),3);
          [~,Id_agg]=min(Dyx_agg,[],2);
          LP=Class(Id_agg);
          AccAgg(1,j)=sum(LP==LY)/length(LY);
    end



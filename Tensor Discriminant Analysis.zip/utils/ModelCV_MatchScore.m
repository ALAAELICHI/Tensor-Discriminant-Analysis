function [par]=ModelCV_MatchScore(obj,train,test,show)
%extract data from obj
if nargin==3,show=[];end
par=obj.par;
REG=par.Reg;
DimSample=obj.in.DimSample;
if strfind(obj.info.Method,'LDA')==1;F='LDA';else,F=['TLDA_',obj.opt.TypeProd];end

K=size(train,2);
Rk1=0;
Rk5=0;
 for k=1:K
     xtrain=ExtractTensor(obj.in.DataTrain,train(:,k),DimSample);ltrain=obj.in.LabelTrain(train(:,k));
     xtest=ExtractTensor(obj.in.DataTrain,test(:,k),DimSample); ltest=obj.in.LabelTrain(test(:,k));

    obj.model=struct('Sw',[],'Sb',[],'alpha',[],'U',[],'V',[],'Mu',[]);
    obj.model=feval(F,obj,xtrain,ltrain); %init model
    RK1=[];RK5=[];
    for j=1:length(REG)

         dispstat(sprintf('>> Cross validation --> fold=[%d,%d] - gamma= %f',k,K,log10(REG(j))),'timestamp');
        obj.par.Reg=REG(j);
        obj.model.U=[];
        obj.model=feval(F,obj,xtrain,ltrain); %solve model
        x=feval(F,obj,xtrain,ltrain); %projection training
        y=feval(F,obj,xtest,ltest);    %projection test
        dim=SampleDim(size(x,2));
        %compute performance
        [rk1,rk5]=MatchScore(dim,x,ltrain,y,ltest);
        
        RK1=[RK1,rk1(:)];
        RK5=[RK5,rk5(:)];
     end
    Rk1=((k-1)*Rk1+RK1)/k;
     Rk5=((k-1)*Rk5+RK5)/k;
 end

if ~isempty(show),
    ShowRank(dim,REG,Rk1,show);
    ylabel('Rank 1 rec.rate');
    ShowRank(dim,REG,Rk5,show+1);
    ylabel('Rank 5 rec.rate');
end
   
par.Reg=[];
Rk1_M=max(Rk1(:));
[id,jd]=find(Rk1==Rk1_M);
%update par
par.DimLDA(1)=dim(id(1));
%par.Reg(1)=REG(jd(1));

Rk5_M=max(Rk5(:));
[id,jd]=find(Rk5==Rk5_M)
%update par
par.DimLDA(2)=dim(id(1));
par.Reg=REG(jd(1));

dispstat(sprintf('>> Result cross validation: Rank 1 = %f% - Dim= %d% - Reg= %f%',Rk1_M,par.DimLDA(1),par.Reg(1)),'keepthis','timestamp');
dispstat(sprintf('>> Result cross validation: Rank 5 = %f% - Dim= %d% - Reg= %f%',Rk5_M,par.DimLDA(2),par.Reg(2)),'keepthis','timestamp');

function [tab]=SampleDim(NProj)

i2=NProj;

%projection sampling
if i2<100,   tab=linspace(1,i2,i2);end
if (i2>=100)&(i2<1000),tab=round(linspace(1,i2,100));end
if (i2>=1000),tab=round(linspace(1,1000,250));end


function ShowRank(tab,Reg,Acc,show)

x=mean(Acc);
[~,id]=sort(x,'descend');

N=size(Acc,2);
c=linspace(0,1,N)';
color=[c,c,c];
figure(show)
clf;
    for k=1:length(id)
      if k==1
        h{k}=plot(tab(:),Acc(:,id(k)),'Color',color(k,:),'LineWidth',2);
                hold on
            [u,v]=max(Acc(:,id(k)));
            plot([tab(v) tab(v)],[min(Acc(:)) u],'--r');
        else
           h{k}=plot(tab(:),Acc(:,id(k)),'Color',color(k,:));
       end
    end
grid on
  legend(h{1},['\gamma= ',num2str(Reg(id(1)))], 'location','southeast');
m=min(Acc(:))-0.02;
M=max(Acc(:))+0.02;
xlabel('Dimension');

%axis([0 size(Acc,1) m M]);
% figure(1)
% clf;
% subplot(1,2,1)
% hist(double(ltrain),double([min(ltrain):max(ltrain)]));
% subplot(1,2,2)
% hist(double(ltest),double([min(ltest):max(ltest)]));
% pause

function [X,DimSample]=DataReshape(X,method,TypeProd)

dim=size(X);
N=dim(end);
DimSample=length(dim);

switch method
   
case {'LDA','KDA','ULDA'}
      X=reshape(X,prod(dim(1:end-1)),N);
      DimSample=2;
case {'TLDA','TNLDA','TNKDA'}
      if (TypeProd=='c')|(TypeProd=='t') %rearrangment of the dimensions of the tensor
          perm=1:DimSample;
          perm=[perm(1:2),DimSample,perm(3:end-1)];
          X=permute(X,perm);
          dim=size(X);
          X=reshape(X,[prod(dim(1:2)),dim(3),prod(dim(4:end))]);
          DimSample=2;
      end
     
          
end
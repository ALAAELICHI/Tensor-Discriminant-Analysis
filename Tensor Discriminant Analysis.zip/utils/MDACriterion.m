function [rho]=MDACriterion(Sb,Sw,U)

B=trace(U'*Sb*U);
W=trace(U'*Sw*U);
rho=B/W;
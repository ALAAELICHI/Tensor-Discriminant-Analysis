function [IdTrain,IdTest]=DataPartition(LX,varargin)
kClass=[];
kFold=[];
nVarargs = length(varargin);
for k = 1:2:nVarargs    
  if strcmp(varargin{k},'ByClass'),kClass=varargin{k+1}; end 
  if strcmp(varargin{k},'ByFold'),kFold=varargin{k+1}; end 
end



if ~isempty(kClass)

    C=unique(LX);

    for k=1:kClass
        itrain=[];itest=[];
        for c=1:length(C)
            id=find(LX==C(c));
            j=randperm(length(id));
            id=id(j);
            %cut in 2 parts
            Ncut=round(length(id)/2);
            itrain=[itrain;id(1:Ncut)];
            itest=[itest;id(Ncut+1:end)];
        end
    IdTrain(:,k)=itrain;
    IdTest(:,k)=itest;
    end
end

if ~isempty(kFold)

    N=length(LX);
    cv=cvpartition(N,'Kfold',kFold);
    for k=1:kFold
        IdTrain(k)=find(cv.training(k));
        IdTest(k)=find(cv.test(k));
    end
end
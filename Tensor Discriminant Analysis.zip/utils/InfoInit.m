
function [info]=InfoInit(obj,FileName,TargetLabels)

info=obj.info;
m=matfile(FileName);
info.DimData=size(m.fea); %dimensions
info.DataLabels=unique(m.label);  %Data Labels
info.TargetLabels=InitTargetLabels(TargetLabels,info.DataLabels);
info.FileName=FileName;





function [TargetLabels]=InitTargetLabels(TargetLabels,DataLabels)
%%%% define Target labels
N=length(DataLabels);
if isempty(TargetLabels)
    clc;
    disp('>> categories:');
    for k=1:N,disp([num2str(k),': ',DataLabels(k)]);end
    
    rep=input('>> enter target class(all classes enter: <<all>>, 1,3,5 ): ','s');
    if strcmp(rep,'all')
        TargetLabels = categorical.empty(N,0);
        TargetLabels=DataLabels;
    else
        id=str2num(rep);
        TargetLabels=DataLabels(id);
        %if size(TargetLabels,1)==1,TargetLabels=['outliers';TargetLabels];end
    end
       
else
if TargetLabels=='all',TargetLabels=DataLabels;end
end
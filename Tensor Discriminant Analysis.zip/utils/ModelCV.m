function [par]=ModelCV_Agg(obj,train,test,show)
%extract data from obj
if nargin==3,show=[];end
par=obj.par;
REG=par.Reg;
DimSample=obj.in.DimSample;
if strfind(obj.info.Method,'LDA')==1;F='LDA';else,F=['TLDA_',obj.opt.TypeProd];end

Acc=0;AccAgg=0;
K=size(train,2);
for k=1:K
   

     xtrain=ExtractTensor(obj.in.DataTrain,train(:,k),DimSample);ltrain=obj.in.LabelTrain(train(:,k));
     xtest=ExtractTensor(obj.in.DataTrain,test(:,k),DimSample); ltest=obj.in.LabelTrain(test(:,k));


     obj.model=struct('Sw',[],'Sb',[],'alpha',[],'U',[],'V',[],'Mu',[]);
     obj.model=feval(F,obj,xtrain,ltrain); %init model
   
     for j=1:length(REG)

dispstat(sprintf('>> Cross validation --> fold=[%d,%d] - gamma= %f',k,K,log10(REG(j))),'timestamp');

        obj.par.Reg=REG(j);
        obj.model.U=[];
        obj.model=feval(F,obj,xtrain,ltrain); %solve model
        x(:,:,j)=feval(F,obj,xtrain,ltrain); %projection training
        y(:,:,j)=feval(F,obj,xtest,ltest);    %projection test
      
     end
 dim=SampleDim(size(x,2));  
 
[acc,accagg,tab]=NNAgg(dim,x,ltrain,y,ltest);
%disp(['>> Acc= ',num2str(max(acc(:))),' - Acc Agg= ',num2str(max(accagg(:)))]);  
Acc=Acc+acc;
AccAgg=AccAgg+accagg;
end
Acc=Acc/K;
AccAgg=AccAgg/K;

if ~isempty(show),
    ShowAcc(tab,REG,Acc,show);
    ShowAcc(tab,REG,AccAgg,show+1);
end


AccM=max(Acc(:));
[id,jd]=find(Acc==AccM);

    %update par
par.DimLDA=tab(id(1));
par.Reg=REG(jd(1));
dispstat(sprintf('>> Result cross validation: Acc= %f% - Dim= %d% - Reg= %d%',AccM,par.DimLDA,par.Reg),'keepthis','timestamp');


function [tab]=SampleDim(NProj)

i2=NProj;

%projection sampling
if i2<100,   tab=linspace(1,i2,i2);end
if (i2>=100)&(i2<1000),tab=round(linspace(1,i2,100));end
if (i2>=1000),tab=round(linspace(1,1000,250));end


function ShowAcc(tab,Reg,Acc,show)

x=mean(Acc);
[~,id]=sort(x,'descend');

N=size(Acc,2);
c=linspace(0,1,N)';
color=[c,c,c];
figure(show)
clf;
    for k=1:length(id)
      if k==1
        h{k}=plot(tab(:),Acc(:,id(k)),'Color',color(k,:),'LineWidth',2);
                hold on
            [u,v]=max(Acc(:,id(k)));
            plot([tab(v) tab(v)],[min(Acc(:)) u],'--r');
        else
           h{k}=plot(tab(:),Acc(:,id(k)),'Color',color(k,:));
       end
    end
grid on
  legend(h{1},['\gamma= ',num2str(Reg(id(1)))], 'location','southeast');
m=min(Acc(:))-0.02;
M=max(Acc(:))+0.02;
xlabel('Dimension');
ylabel('Acc');
%axis([0 size(Acc,1) m M]);
% figure(1)
% clf;
% subplot(1,2,1)
% hist(double(ltrain),double([min(ltrain):max(ltrain)]));
% subplot(1,2,2)
% hist(double(ltest),double([min(ltest):max(ltest)]));
% pause

function [err]=StopCrit(Uold,Unew)

Nmode=size(Uold,2);
crit=0;
for k=1:Nmode
    dimout=size(Uold{k},1);
    I=eye(dimout);
    A=Uold{k}*Unew{k}';
   crit=crit+norm(A-I,'fro')/(dimout.^2);
    
end
err=crit/Nmode;
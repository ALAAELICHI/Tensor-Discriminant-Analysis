function [in]=ReadDataFromMat(obj,varargin)

in=obj.in;
NbyClass=[];NbyRand=[];PcTrain=0.8;Id=[];

nVarargs = length(varargin);
for k = 1:2:nVarargs    
  if strcmp(varargin{k},'NbyRand'),NbyRand=varargin{k+1}; end 
  if strcmp(varargin{k},'NbyClass'),NbyClass=varargin{k+1}; end 
  if strcmp(varargin{k},'PcTrain'),PcTrain=varargin{k+1}; end 
end

m=matfile(obj.info.FileName);
data=m.fea; %extract data
label=m.label;%extract label
label=label(:);
DimData=size(data);
%class=unique(label);

vars = whos('-file',obj.info.FileName);
if ismember('Id', {vars.name}),Id=m.Id;end

if isempty(Id)
     
    if ~isempty(NbyClass), %CV by fixing the number of tensor by classes: learn data
        ik=ExtractNbyClass(label,NbyClass);
        in.DataTrain=ExtractTensor(data,ik,DimData(end));
        in.LabelTrain=label(ik);
    end
    if ~isempty(NbyRand),  % random sampling : learn data and test data
        ik=randperm(DimData(end));ik=ik(1:NbyRand);
        ntrain=round(NbyRand*PcTrain);
        itrn=ik(1:ntrain);
        itst=ik(ntrain+1:end);
        in.DataTrain=ExtractTensor(data,itrn,DimData(end));
        in.LabelTrain=label(itrn);
        in.DataTest=ExtractTensor(data,itst,DimData(end));
        in.LabelTest=label(itst);
        in.Id=[];
    end  
else
    
    if ~isempty(NbyClass),%CV by fixing the number of tensor by classes: learn data
        ik=1:Id(1);%index of the learning data
        ik=ExtractNbyClass(label(ik),NbyClass);
        in.DataTrain=ExtractTensor(data,ik,DimData(end));
        in.LabelTrain=label(ik);
    else
        index=1:Id(1);%index of the learning data
        in.DataTrain=ExtractTensor(data,index,DimData(end));
        in.LabelTrain=label(index);
        index=Id(1)+1:Id(end);
        in.DataTest=ExtractTensor(data,index,DimData(end));
        in.LabelTest=label(index);
        ID=[];
        for k=2:length(Id)
            ID=[ID;[Id(k-1)+1,Id(k)]];
        end
        in.Id=ID-Id(1);
    end
end


        in.DataTrain=DataScale(double(in.DataTrain),obj.opt.ModeScale); %scale data 
        [in.DataTrain,in.DimSample]=DataReshape(in.DataTrain,obj.info.Method,obj.opt.TypeProd);%reshape data according to method
        if ~isempty(in.DataTest)       
            in.DataTest=DataScale(double(in.DataTest),obj.opt.ModeScale); %scale data 
            [in.DataTest,~]=DataReshape(in.DataTest,obj.info.Method,obj.opt.TypeProd);%reshape data according to method
        end

    function [ik]=ExtractNbyClass(label,NbyClass)
    class=unique(label);
     ik=[];
        for k=1:length(class)
            Ik=find(label==class(k));
            Nk=length(Ik);
            if Nk>NbyClass,Nk=NbyClass;end
            ik=[ik;Ik(1:Nk)];
        end
    


clear all
close all

% S=load('TPCA200-TLDA-ROT');
% S1=load('TPCA200-TLDA-TRO');
S=load('LDA-TRO');
S1=load('TLDA-TRO_001');
S2=load('TLDA-TRO_01');

figure(2)
clf;
h(1)=stdshade(S.Acc,0.3,'b',S.DimLDA);
hold on
h(2)=stdshade(S1.Acc,0.2,'g',S.DimLDA);
h(3)=stdshade(S2.Acc,0.3,'r',S.DimLDA);

grid on
title('LDA vs TLDA : t-product')
xlabel('DimLDA');
ylabel('Accuracy');
axis([0.1 1 min([S.Acc(:);S1.Acc(:)])-0.01 max([S.Acc(:);S1.Acc(:)])+0.01])

legend(h,'LDA ','TLDA_{\gamma=0.01}','TLDA_{\gamma=0.1}')
axis square
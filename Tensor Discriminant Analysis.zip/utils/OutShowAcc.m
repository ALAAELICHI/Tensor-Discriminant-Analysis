function OutShowAcc(Reg,Acc,AccAgg,Show)

[proj,reg]=size(Acc);
% Acc vs proj
Acc_p=max(Acc,[],2);[Acc_p_M,i1]=max(Acc_p);
AccAgg_p=max(AccAgg,[],2);[AccAgg_p_M,i2]=max(Acc_p);
% Acc vs reg
Acc_reg=max(Acc,[],1);
AccAgg_reg=max(AccAgg,[],1);

figure(Show)
clf;
    subplot(1,2,1)
    h1=plot(1:proj,Acc_p*100,'b');
    hold on
    h2=plot(1:proj,AccAgg_p*100,'r');
    xlabel('number of learners');
    ylabel('Acc(%)');
    legend([h1,h2],'Acc.','Agg. acc.');
%     plot([i1,i1],[0,Acc_p_M*100],'--g')
%     plot([i1,i1],[0,AccAgg_p_M*100],'--g')
    grid on
    
    subplot(1,2,2)
    h1=semilogx(Reg,Acc_reg*100);
    hold on
    h2=semilogx(Reg,AccAgg_reg*100);
    xlabel('Regularization');
    ylabel('Acc(%)');
    legend([h1,h2],'Acc.','Agg. acc.');
    grid on
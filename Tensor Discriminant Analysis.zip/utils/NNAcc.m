function [Acc]=NNAcc(dim,x,ltrain,y,ltest)

for i=1:length(dim),
    [lpredict,~]=NN(x(:,1:dim(i)),ltrain,y(:,1:dim(i)));
    Acc(i)=sum(lpredict==ltest)/length(ltest); 
end
  
    
 
 
       